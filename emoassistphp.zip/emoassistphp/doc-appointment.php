<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

include_once("db_config.php");

// Assume you receive data via POST request
$data = json_decode(file_get_contents("php://input"), true);

// Assuming your data has the same structure as the form
$patientName = $data['patientName'];
$dateTime = $data['dateTime'];
$doctor = $data['doctor'];
$purpose = $data['purpose'];
$contactNumber = $data['contactNumber'];
$email = $data['email'];

// Convert the date and time to a format compatible with MySQL datetime
$formattedDateTime = date("Y-m-d H:i:s", strtotime($dateTime));

$sql = "INSERT INTO doc_api (patientName, dateTime, doctor, purpose, contactNumber, email) 
        VALUES ('$patientName', '$formattedDateTime', '$doctor', '$purpose', '$contactNumber', '$email')";

if ($conn->query($sql) === TRUE) {
    echo json_encode(["success" => true, "message" => "Data saved successfully"]);
} else {
    echo json_encode(["success" => false, "message" => "Error: " . $sql . "<br>" . $conn->error]);
}

$conn->close();
?>
