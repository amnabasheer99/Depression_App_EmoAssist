<?php
header("Content-Type: application/json");
header("Access-Control-Allow-Origin: *");
header("Access-Control-Allow-Methods: POST");
header("Access-Control-Allow-Headers: Content-Type");

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

require 'PHPMailer-master/PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/PHPMailer-master/src/SMTP.php';

// Get data from the frontend
$postData = json_decode(file_get_contents("php://input"), true);

// Extract user and parent emails
$userEmail = $postData['user_email'];
$parentEmail = $postData['parent_email'];

// Send an email using PHPMailer
$mail = new PHPMailer(true);

try {
    $mail->isSMTP();
    $mail->Host = 'smtp.gmail.com'; // Replace with your SMTP server
    $mail->SMTPAuth = true;
    $mail->Username = 'amna.united.mn@gmail.com'; // Replace with your SMTP username
    $mail->Password = 'zheo lvfy qjrs xjuy'; // Replace with your SMTP password
    $mail->SMTPSecure = 'tls'; // Enable TLS encryption, `ssl` also accepted
    $mail->Port = 587; // TCP port to connect to

    $mail->setFrom('depression-detection@emoassist.com', 'EmoAssist');

    // Send an email to the doctor
    $doctorEmail = 'amna.athiyaba@gmail.com'; // Replace with the actual doctor's email
    $mail->addAddress($doctorEmail);
    $mail->isHTML(true);
    $mail->Subject = 'Patient Depression Notification';
    $mail->Body = "Patient with email $userEmail has been diagnosed with depression.";

    $mail->send();

    // Send an email to the parent
    $mail->clearAddresses();
    $mail->addAddress($parentEmail);
    $mail->Subject = 'Child Depression Notification';
    $mail->Body = "Your child with email $userEmail has been diagnosed with depression.";

    $mail->send();

    echo json_encode(['success' => true, 'message' => 'Emails sent successfully.']);
} catch (Exception $e) {
    echo json_encode(['success' => false, 'error' => 'Email could not be sent. Mailer Error: ' . $mail->ErrorInfo]);
}
?>
