// Sidebar.tsx
import React, { useState } from "react";
import { Link } from "react-router-dom";

const Sidebar: React.FC = () => {
  const [isSidebarOpen, setSidebarOpen] = useState(true);

  const toggleSidebar = () => {
    setSidebarOpen(!isSidebarOpen);
  };

  const sidebarContentStyle: React.CSSProperties = {
    display: isSidebarOpen ? "block" : "none", "zIndex" : "1000",
  };

  return (
    <nav className={`col-md-3 col-lg-2 d-md-block bg-light sidebar ${isSidebarOpen ? "show" : ""}`}>
      <div className="sidebar-sticky">
        <button className="btn btn-light" onClick={toggleSidebar}>
          ☰ Toggle Sidebar
        </button>
        {/* Other Sidebar content goes here */}
        <div id="sidebarContent" style={sidebarContentStyle}>
          <ul className="nav flex-column">
          <li className="nav-item">
              <Link className="nav-link" to="/doc-appointment">
                Doctor Appointment
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/another-page">
                Another Page
              </Link>
            </li>
            <li className="nav-item">
              <Link className="nav-link" to="/yet-another-page">
                Yet Another Page
              </Link>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  );
};

export default Sidebar;
