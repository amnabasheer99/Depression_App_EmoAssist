import React, { useEffect, useState } from 'react';
import { useClerk } from '@clerk/clerk-react';
import { useNavigate } from 'react-router-dom';


function DiagnosisPage() {
  const { user } = useClerk();
  const [parentEmail, setParentEmail] = useState('');

  const navigate = useNavigate();


  const handleSubmit = () => {
    // Check if user is authenticated
    if (user) {
      // User is authenticated, send user's and parent's email addresses to your PHP backend
      const userEmail = user.primaryEmailAddress?.emailAddress;

      console.log(userEmail);

      // Example: Send a POST request to your PHP backend
      fetch('http://localhost/emoassistphp/saveEmail.php', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          user_email: userEmail,
          parent_email: parentEmail,
        }),
      })
        .then(response => response.json())
        .then(data => {
          console.log('Response from PHP backend:', data);
          
          // Check if the backend responds with success
          if (data.success) {
            // Show an alert
            alert('Emails sent successfully!');
            
            // Navigate back to the dashboard
            navigate("/");
          } else {
            // Handle unsuccessful response if needed
            alert('Error sending emails. Please try again.');
          }
        })
        .catch(error => {
          console.error('Error sending email to PHP backend:', error);
          alert('Error sending emails. Please try again.');
        });
    }
  };

  return (
    <section id='parentemail'>
        <div  className="container mt-5">
      <div className="card">
        <div className="card-body">
          <h5 className="card-title">Parent/Guardian Email Form</h5>
          <div className="form-group">
            <label htmlFor="parentEmail">Parent/Guardian Email:</label>
            <input
              type="email"
              className="form-control"
              id="parentEmail"
              value={parentEmail}
              onChange={(e) => setParentEmail(e.target.value)}
            />
          </div>
          <button type="button" className="btn btn-primary" onClick={handleSubmit}>
            Submit
          </button>
        </div>
      </div>
    </div>
    </section>
  );
}

export default DiagnosisPage;
