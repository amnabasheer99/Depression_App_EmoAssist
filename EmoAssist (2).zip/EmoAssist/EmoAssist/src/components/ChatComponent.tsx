import React, { useState, useEffect, useRef } from 'react';
import axios from 'axios';
import { FaRocket } from 'react-icons/fa';
import { useClerk } from '@clerk/clerk-react';
import { useNavigate } from 'react-router-dom';

 // Counter for forbidden words
 let forbiddenWordCount = 0;

 const messagesEndRef = React.createRef()

 

const ChatComponent = () => {
  const { user } = useClerk();
  const [userMessage, setUserMessage] = useState('');
  const [chatHistory, setChatHistory] = useState([]);
  const chatContainerRef = useRef();

  const navigate = useNavigate();


  const sendMessage = async () => {
    if (userMessage.trim() === '') return;
  
    // Define the words you want to check for
    const forbiddenWords = ['kill', 'die', 'tired','suicide','anxiety']; // Add your specific words here
  
      // Check if any forbidden words are present in the user message
      forbiddenWords.forEach(word => {
        if (userMessage.toLowerCase().includes(word.toLowerCase())) {
          forbiddenWordCount++;
        }
      });

   // Display alert if forbidden words are used more than thrice
  if (forbiddenWordCount > 3) {
    alert('You have been diagnosed with depression');
    navigate('/diagnosis');
    return;
  }
  
    try {
      const response = await axios.post('http://localhost:5000/api/chat', {
        user_id: user.id,
        message: userMessage,
      });
  
      const chatResponse = response.data.response;
  
      setChatHistory((prevHistory) => [
        ...prevHistory,
        { role: 'user', content: `You: ${userMessage}` },
        { role: 'bot', content: `EmoAssist: ${chatResponse}` },
      ]);
  
      setUserMessage('');
    } catch (error) {
      console.error('Error sending message:', error);
    }
  };

 

  const loadChatHistory = async () => {
    try {
      const response = await axios.get(`http://localhost:5000/api/chat/${user.id}`);
      const loadedChatHistory = response.data.history;
      setChatHistory(loadedChatHistory);
    } catch (error) {
      console.error('Error loading chat history:', error);
    }
  };

  useEffect(() => {
    // Load chat history when the component mounts
    loadChatHistory();
  }, []); // Empty dependency array ensures the effect runs only once

 
 
  

  return (
    <div id="chatContainer" >
            <h5 id="chatHeader">EmoAssist is here to help!</h5>

      <div id="chatSection">
        <div>
          <div className="chat-container">
            {chatHistory.map((item, index) => (
              <div
                key={index}
                className={`message ${item.role === 'user' ? 'user-message' : 'bot-message'}`}
              >
                {item.content}

              </div>

            ))}
          </div>
        </div>
        
      </div>
      <div id="promptSection">
        <input
          id="messageBox"
          type="text"
          value={userMessage}
          onChange={(e) => setUserMessage(e.target.value)}
          placeholder="Talk to me..."
        />
        <button id="sendButton" onClick={sendMessage}>
          <FaRocket />
        </button>
      </div>
    </div>
  );
};

export default ChatComponent;