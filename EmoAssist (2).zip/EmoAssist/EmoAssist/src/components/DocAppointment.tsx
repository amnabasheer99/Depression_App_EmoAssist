import React, { useState } from "react";

const DocAppointment = () => {
  const [formData, setFormData] = useState({
    patientName: "",
    dateTime: "",
    doctor: "",
    purpose: "",
    contactNumber: "",
    email: "",
  });

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData((prevData) => ({
      ...prevData,
      [name]: value,
    }));
  };

  const handleSubmit = (e) => {
    e.preventDefault();
  
    // Add logic to handle form submission (e.g., send data to the server)
    console.log("Form submitted:", formData);
  
    // Make an AJAX request to the PHP endpoint
    fetch("http://localhost/emoassistphp/doc-appointment.php", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(formData),
    })
      .then((response) => response.json())
      .then((data) => {
        console.log("Response from server:", data);
  
        // Add logic to handle the response, such as displaying a success message
      })
      .catch((error) => {
        console.error("Error:", error);
      });
  };
  
  return (
    <>
    <br />
    <br />
    <br />
    <br />
    
    <section id="docapp">
      <div className="container">
        <div className="row">
          <div className="col-md-8 offset-md-2">
            <h2 id="docheader">Create Doctor Appointment</h2>
            <form onSubmit={handleSubmit}>
              <div className="mb-3">
                <label htmlFor="patientName" className="form-label">
                  Patient Name
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="patientName"
                  name="patientName"
                  value={formData.patientName}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label htmlFor="dateTime" className="form-label">
                  Date and Time
                </label>
                <input
                  type="datetime-local"
                  className="form-control"
                  id="dateTime"
                  name="dateTime"
                  value={formData.dateTime}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label htmlFor="doctor" className="form-label">
                  Doctor
                </label>
                <input
                  type="text"
                  className="form-control"
                  id="doctor"
                  name="doctor"
                  value={formData.doctor}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label htmlFor="purpose" className="form-label">
                  Purpose/Reason
                </label>
                <textarea
                  className="form-control"
                  id="purpose"
                  name="purpose"
                  value={formData.purpose}
                  onChange={handleChange}
                  required
                ></textarea>
              </div>

              <div className="mb-3">
                <label htmlFor="contactNumber" className="form-label">
                  Contact Number
                </label>
                <input
                  type="tel"
                  className="form-control"
                  id="contactNumber"
                  name="contactNumber"
                  value={formData.contactNumber}
                  onChange={handleChange}
                  required
                />
              </div>

              <div className="mb-3">
                <label htmlFor="email" className="form-label">
                  Email
                </label>
                <input
                  type="email"
                  className="form-control"
                  id="email"
                  name="email"
                  value={formData.email}
                  onChange={handleChange}
                  required
                />
              </div>

              <button type="submit" className="btn btn-primary">
                Submit
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
    </>
  );
};

export default DocAppointment;
