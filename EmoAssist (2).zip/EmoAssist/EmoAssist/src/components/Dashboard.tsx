// Dashboard.tsx
import React from "react";
import ChatComponent from "./ChatComponent";
import Sidebar from "./Sidebar";
import "bootstrap/dist/css/bootstrap.min.css";


const Dashboard: React.FC = () => {
  return (
    <>
      <section id="dashboard">
        <div className="container">
          <div className="row mt-5">
             {/* Sidebar */}
        {/*<Sidebar />*/}

      {/* Main Content */}
      <main className="col-md-12 ml-sm-auto col-lg-12 px-md-4">
        <ChatComponent />
      </main>
                </div>
              </div>
            </section>
    </>
  );
};

export default Dashboard;
